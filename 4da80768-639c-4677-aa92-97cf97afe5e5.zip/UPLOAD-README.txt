LOOKOUT TOWERS FUND — READY-TO-UPLOAD HTML

UPLOAD THE FOLDER VERSION
1. Unzip Lookout-Towers-HTML.zip.
2. Upload index.html, apply.html, and the entire assets folder into the same website folder.
3. Open index.html or your hosting URL. No Node.js, framework, build command, or installation is needed.

SINGLE-FILE VERSION
Lookout-Towers-Single-File.html contains the landing page, investor guide, fonts, scripts, and used images in one file. Upload or rename it to index.html. The investor guide opens inside the same file. An internet connection is needed only when a visitor follows an external Lookout contact, portal, privacy, or terms link.

WHAT IS INCLUDED
- Reference-style landing page with13main sections, grouped FAQs, counters, scroll effects, a timeline, property galleries/dialogs, and responsive navigation.
- Seven-step investor conversation guide, with back/edit/restart and browser-local selections.
-35source images,5local WOFF2fonts and their licenses, plus a favicon.
- Existing Lookout enquiry, portal, privacy and terms links.
- Plain editable HTML, CSS and JavaScript. No tracking pixels, source-site scripts or external font/image dependencies.

ENQUIRIES AND BOOKINGS
The guide does not pretend to submit answers. Its final button opens the existing Lookout form at https://lookouttowerfund.com/invest-with-us-2116. That existing live form handles the contact process. No new backend is required by this package.

EDITING
Copy and figures: index.html. Guide questions: assets/js/apply.js. Colors, type and spacing: assets/css/site.css. Application layout: assets/css/apply.css. Images: assets/images. Regenerate an embedded single-file version if you edit the folder version; they are separate deliverables.

SOURCE TERMS
Uses the existing Lookout details supplied through its public website. SeriesAis represented as15%annualized target,12-month hold; SeriesBas25%total target over3years, following the detailed /invest page. Returns are targets rather than guarantees. Full terms are governed by offering documents. The reconstruction notes identify material differences from the design reference.
