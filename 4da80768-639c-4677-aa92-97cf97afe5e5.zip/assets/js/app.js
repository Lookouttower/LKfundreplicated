/* Lookout Towers Fund — standalone reference-style interactions. */
(() => {
  'use strict';

  const ready = callback => {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', callback, { once: true });
    } else {
      callback();
    }
  };

  ready(() => {
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const compactQuery = window.matchMedia('(max-width: 1023px)');
    const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
    const scrollBehavior = () => motionQuery.matches ? 'instant' : 'smooth';
    const header = document.getElementById('site-header');
    const menu = document.getElementById('mobile-nav-menu');
    const menuToggles = [...document.querySelectorAll('[data-menu-toggle]')];
    const progress = document.getElementById('scroll-progress');
    const stickyCTA = document.getElementById('sticky-cta');
    const timelines = [...document.querySelectorAll('.timeline')];
    let menuIsOpen = false;

    const setMenu = (open, restoreFocus = false) => {
      menuIsOpen = Boolean(open && menu);
      if (menu) menu.hidden = !menuIsOpen;
      menuToggles.forEach(button => {
        button.setAttribute('aria-expanded', String(menuIsOpen));
        button.setAttribute('aria-label', menuIsOpen
          ? (button.dataset.labelClose || 'Close navigation menu')
          : (button.dataset.labelOpen || 'Open navigation menu'));
        button.classList.toggle('is-open', menuIsOpen);
      });
      if (restoreFocus && menuToggles[0]) {
        menuToggles[0].focus({ preventScroll: true });
      }
    };

    menuToggles.forEach(button => button.addEventListener('click', () => {
      setMenu(!menuIsOpen);
    }));
    if (menu) {
      menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));
    }
    document.addEventListener('pointerdown', event => {
      if (!menuIsOpen || !menu || menu.contains(event.target)) return;
      if (menuToggles.some(button => button.contains(event.target))) return;
      setMenu(false);
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && menuIsOpen) setMenu(false, true);
    });
    compactQuery.addEventListener('change', event => {
      if (!event.matches) setMenu(false);
      requestScrollUpdate();
    });

    document.querySelectorAll('a[href^="#"]').forEach(link => {
      link.addEventListener('click', event => {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        const hash = link.getAttribute('href');
        if (!hash || hash === '#') return;
        let id;
        try { id = decodeURIComponent(hash.slice(1)); } catch { return; }
        const target = document.getElementById(id);
        if (!target) return;
        event.preventDefault();
        setMenu(false);
        target.scrollIntoView({ behavior: scrollBehavior(), block: 'start' });
        try { window.history.pushState(null, '', hash); } catch { /* file previews still scroll normally. */ }
        // Make the skip link useful to keyboard and screen-reader users.
        if (link.classList.contains('skip-link') || link.textContent.trim().toLowerCase().startsWith('skip')) {
          if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
          target.focus({ preventScroll: true });
        }
      });
    });

    const navigationLinks = [...document.querySelectorAll('#site-header a[href^="#"], #mobile-nav-menu a[href^="#"]')];
    const navigationSections = [...new Set(navigationLinks.map(link => link.getAttribute('href').slice(1)))]
      .map(id => document.getElementById(id)).filter(Boolean)
      .sort((a, b) => a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
    let currentSection = '';
    let scrollFrame = 0;

    function updateScroll() {
      scrollFrame = 0;
      const y = window.scrollY || document.documentElement.scrollTop;
      const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      if (header) {
        header.classList.toggle('is-compact', y > 60);
        header.classList.toggle('is-scrolled', y > 60);
      }
      if (progress) {
        progress.style.transformOrigin = 'left center';
        progress.style.transform = `scaleX(${max > 0 ? clamp(y / max) : 0})`;
      }
      if (stickyCTA) stickyCTA.hidden = !(y > 620 && compactQuery.matches);

      let sectionID = '';
      const threshold = Math.min(200, window.innerHeight * 0.27);
      navigationSections.forEach(section => {
        if (section.getBoundingClientRect().top <= threshold) sectionID = section.id;
      });
      if (sectionID !== currentSection) {
        currentSection = sectionID;
        navigationLinks.forEach(link => {
          const active = link.getAttribute('href') === `#${sectionID}`;
          link.classList.toggle('is-active', active);
          if (active) link.setAttribute('aria-current', 'location');
          else link.removeAttribute('aria-current');
        });
      }
      timelines.forEach(timeline => {
        const fill = timeline.querySelector('[data-timeline-progress]');
        if (!fill) return;
        const box = timeline.getBoundingClientRect();
        const amount = clamp((window.innerHeight * 0.6 - box.top) / Math.max(1, box.height - window.innerHeight * 0.2));
        fill.style.height = `${amount * 100}%`;
      });
    }

    function requestScrollUpdate() {
      if (!scrollFrame) scrollFrame = window.requestAnimationFrame(updateScroll);
    }
    window.addEventListener('scroll', requestScrollUpdate, { passive: true });
    window.addEventListener('resize', requestScrollUpdate, { passive: true });
    updateScroll();

    // These elements are readable in the HTML itself. Motion is progressive
    // enhancement: only this script applies the temporary hidden state.
    const revealElements = [...document.querySelectorAll('[data-reveal]')];
    const revealAnimations = new Map();
    let revealObserver;
    const showReveal = element => {
      revealObserver?.unobserve(element);
      element.classList.add('is-revealed');
      element.style.opacity = '';
      element.style.filter = '';
      element.style.transform = '';
      if (motionQuery.matches || !element.animate) return;
      const delay = clamp(Number(element.dataset.revealDelay) || 0, 0, 500);
      const animation = element.animate([
        { opacity: 0, filter: 'blur(6px)', transform: 'translateY(-6px)' },
        { opacity: 1, filter: 'blur(0)', transform: 'translateY(0)' }
      ], { duration: 400, delay, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'backwards' });
      revealAnimations.set(element, animation);
      animation.finished.then(() => revealAnimations.delete(element)).catch(() => {});
    };
    if ('IntersectionObserver' in window && !motionQuery.matches) {
      revealObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => { if (entry.isIntersecting) showReveal(entry.target); });
      }, { rootMargin: '0px 0px -50px 0px', threshold: 0.01 });
      revealElements.forEach(element => {
        element.style.opacity = '0';
        element.style.filter = 'blur(6px)';
        element.style.transform = 'translateY(-6px)';
        revealObserver.observe(element);
      });
    } else {
      revealElements.forEach(showReveal);
    }

    const counters = [...document.querySelectorAll('[data-count]')];
    const counterFrames = new Map();
    let counterObserver;
    const counterValue = (element, value) => {
      const decimals = Math.trunc(clamp(Number(element.dataset.decimals) || 0, 0, 6));
      const formatted = value.toLocaleString('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });
      return `${element.dataset.prefix || ''}${formatted}${element.dataset.suffix || ''}`;
    };
    const finishCounter = element => {
      const target = Number(element.dataset.count);
      if (!Number.isFinite(target)) return;
      const frame = counterFrames.get(element);
      if (frame) window.cancelAnimationFrame(frame);
      counterFrames.delete(element);
      element.textContent = counterValue(element, target);
      element.dataset.countAnimated = 'true';
    };
    const startCounter = element => {
      counterObserver?.unobserve(element);
      if (element.dataset.countAnimated === 'true') return;
      const target = Number(element.dataset.count);
      if (!Number.isFinite(target)) return;
      if (motionQuery.matches) return finishCounter(element);
      const started = window.performance.now();
      const duration = 1800;
      const frame = now => {
        const fraction = clamp((now - started) / duration);
        const eased = 1 - Math.pow(1 - fraction, 4);
        element.textContent = counterValue(element, target * eased);
        if (fraction < 1 && !motionQuery.matches) counterFrames.set(element, window.requestAnimationFrame(frame));
        else finishCounter(element);
      };
      counterFrames.set(element, window.requestAnimationFrame(frame));
    };
    if ('IntersectionObserver' in window && !motionQuery.matches) {
      counterObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => { if (entry.isIntersecting) startCounter(entry.target); });
      }, { threshold: 0.15 });
      counters.forEach(element => counterObserver.observe(element));
    } else counters.forEach(finishCounter);

    motionQuery.addEventListener('change', event => {
      if (!event.matches) return;
      revealObserver?.disconnect();
      revealAnimations.forEach(animation => animation.cancel());
      revealAnimations.clear();
      revealElements.forEach(element => {
        element.style.opacity = '';
        element.style.filter = '';
        element.style.transform = '';
        element.classList.add('is-revealed');
      });
      counterObserver?.disconnect();
      counters.forEach(finishCounter);
    });

    document.querySelectorAll('[data-carousel]').forEach(carousel => {
      if (!carousel.id) return;
      if (!carousel.hasAttribute('tabindex')) carousel.tabIndex = 0;
      const buttons = [...document.querySelectorAll('[data-carousel-prev], [data-carousel-next]')]
        .filter(button => button.dataset.carouselTarget === carousel.id);
      const updateButtons = () => {
        const max = Math.max(0, carousel.scrollWidth - carousel.clientWidth);
        buttons.forEach(button => {
          const previous = button.hasAttribute('data-carousel-prev');
          button.disabled = previous ? carousel.scrollLeft <= 2 : carousel.scrollLeft >= max - 2;
        });
      };
      const move = direction => {
        const step = Number(carousel.dataset.carouselStep) || 320;
        carousel.scrollBy({ left: direction * step, behavior: scrollBehavior() });
      };
      buttons.forEach(button => button.addEventListener('click', () => move(button.hasAttribute('data-carousel-prev') ? -1 : 1)));
      carousel.addEventListener('scroll', updateButtons, { passive: true });
      carousel.addEventListener('keydown', event => {
        if (event.target !== carousel || !['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
        event.preventDefault();
        move(event.key === 'ArrowLeft' ? -1 : 1);
      });
      window.addEventListener('resize', updateButtons, { passive: true });
      carousel.querySelectorAll('img').forEach(image => {
        if (!image.complete) image.addEventListener('load', updateButtons, { once: true });
      });
      updateButtons();
    });

    document.querySelectorAll('details[data-faq]').forEach(details => {
      const summary = details.querySelector('summary');
      const updateFAQ = () => {
        if (summary) summary.setAttribute('aria-expanded', String(details.open));
        if (!details.open) return;
        const group = details.dataset.faqGroup || 'default';
        document.querySelectorAll('details[data-faq]').forEach(other => {
          if (other !== details && (other.dataset.faqGroup || 'default') === group) other.open = false;
        });
      };
      details.addEventListener('toggle', updateFAQ);
      if (summary) summary.setAttribute('aria-expanded', String(details.open));
    });

    const dialog = document.getElementById('property-dialog');
    if (dialog) {
      let dialogOpener = null;
      let previousOverflow = '';
      let previousPaddingRight = '';
      let locked = false;
      const field = selector => dialog.querySelector(selector);
      const putText = (selector, value) => {
        const element = field(selector);
        if (element) element.textContent = value || '';
      };
      const restoreDialog = () => {
        if (!locked) return;
        locked = false;
        document.body.style.overflow = previousOverflow;
        document.body.style.paddingRight = previousPaddingRight;
        document.body.classList.remove('dialog-open');
        if (dialogOpener) {
          dialogOpener.setAttribute('aria-expanded', 'false');
          const opener = dialogOpener;
          window.requestAnimationFrame(() => {
            if (opener.isConnected) opener.focus({ preventScroll: true });
          });
        }
      };
      const closeDialog = () => {
        if (!dialog.open) return;
        if (typeof dialog.close === 'function') dialog.close();
        else dialog.removeAttribute('open');
        restoreDialog();
      };
      document.querySelectorAll('[data-property]').forEach(button => {
        button.setAttribute('aria-haspopup', 'dialog');
        button.setAttribute('aria-controls', dialog.id);
        button.setAttribute('aria-expanded', 'false');
        button.addEventListener('click', () => {
          if (dialog.open) return;
          dialogOpener = button;
          putText('[data-dialog-title]', button.dataset.title);
          putText('[data-dialog-category]', button.dataset.category);
          putText('[data-dialog-description]', button.dataset.description);
          const image = field('[data-dialog-image]');
          if (image) {
            const source = button.dataset.image;
            if (source) {
              image.src = source;
              image.alt = button.dataset.imageAlt || button.dataset.title || 'Lookout Towers property';
              image.hidden = false;
            } else {
              image.removeAttribute('src');
              image.hidden = true;
            }
          }
          const tags = field('[data-dialog-tags]');
          if (tags) {
            tags.replaceChildren();
            (button.dataset.tags || '').split('|').map(tag => tag.trim()).filter(Boolean).forEach(text => {
              const tag = document.createElement('span');
              tag.className = 'tag';
              tag.textContent = text;
              tags.appendChild(tag);
            });
          }
          previousOverflow = document.body.style.overflow;
          previousPaddingRight = document.body.style.paddingRight;
          const scrollbar = window.innerWidth - document.documentElement.clientWidth;
          if (scrollbar > 0) document.body.style.paddingRight = `${scrollbar + (parseFloat(getComputedStyle(document.body).paddingRight) || 0)}px`;
          document.body.style.overflow = 'hidden';
          document.body.classList.add('dialog-open');
          locked = true;
          button.setAttribute('aria-expanded', 'true');
          if (typeof dialog.showModal === 'function') dialog.showModal();
          else dialog.setAttribute('open', '');
          const firstFocus = field('[data-dialog-close]') || dialog;
          if (firstFocus === dialog && !dialog.hasAttribute('tabindex')) dialog.tabIndex = -1;
          firstFocus.focus({ preventScroll: true });
        });
      });
      dialog.querySelectorAll('[data-dialog-close]').forEach(button => button.addEventListener('click', closeDialog));
      dialog.addEventListener('cancel', event => {
        event.preventDefault();
        closeDialog();
      });
      dialog.addEventListener('close', restoreDialog);
      dialog.addEventListener('click', event => {
        if (event.target !== dialog) return;
        const box = dialog.getBoundingClientRect();
        if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) closeDialog();
      });
      dialog.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
          event.preventDefault();
          closeDialog();
          return;
        }
        if (event.key !== 'Tab') return;
        const focusable = [...dialog.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')]
          .filter(element => !element.hidden && element.getClientRects().length);
        if (!focusable.length) {
          event.preventDefault();
          dialog.focus();
          return;
        }
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      });
    }
  });
})();
