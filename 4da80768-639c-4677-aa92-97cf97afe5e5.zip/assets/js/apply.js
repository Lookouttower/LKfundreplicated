/* Lookout Towers Fund · local investment-path guide. No answers are submitted. */
(() => {
  'use strict';
  const questions = [
    { id:'accredited', label:'Investor status', kicker:'First, a little context', title:'Are you an accredited investor?', help:'Current Lookout Towers offerings are intended for accredited investors. The team will confirm eligibility during the formal investment process.', options:[['yes','Yes'],['no','No'],['unsure','I’m not sure']] },
    { id:'capital', label:'Investment range', kicker:'Your investment range', title:'What investment amount are you considering?', help:'Published fund investments begin at $50,000. Location-specific opportunities may have different minimums.', options:[['under-50','Under $50,000'],['50-100','$50,000–$99,999'],['100-250','$100,000–$249,999'],['250-plus','$250,000 or more']] },
    { id:'objective', label:'Primary objective', kicker:'What matters most', title:'What would you like this investment to do?', help:'Your goals help frame the conversation around income, growth, and the time you want to commit.', options:[['income','Provide regular income'],['growth','Support long-term growth'],['both','A combination of income and growth'],['exploring','I’m exploring my options']] },
    { id:'interest', label:'Investment path', kicker:'Choose your starting point', title:'Which investment path interests you?', help:'Each path has its own terms, risks, and time horizon. The offering documents explain the details.', options:[['series-a','Series A · Income'],['series-b','Series B · Growth'],['syndication','A location-specific investment'],['compare','Help me compare the options']] },
    { id:'timing', label:'Timing', kicker:'Your timeline', title:'When are you looking to invest?', help:'A rough timeframe is enough. You can review the opportunities at your own pace.', options:[['month','Within the next 30 days'],['quarter','In 1–3 months'],['six-months','In 3–6 months'],['research','I’m researching for the future']] },
    { id:'account', label:'Investment approach', kicker:'How you may invest', title:'How are you considering investing?', help:'Lookout Towers describes personal and self-directed retirement-account options. The team can discuss the process that applies to you.', options:[['personal','With personal funds'],['retirement','Through a self-directed IRA or retirement account'],['entity','Through an entity or trust'],['unsure','I’d like guidance on the options']] },
    { id:'advisor', label:'Advisor support', kicker:'Bring your team', title:'Do you work with an investment or tax advisor?', help:'Reviewing an opportunity with your own qualified advisors can help you assess the terms and how they fit your circumstances.', options:[['tax','I work with a CPA or tax advisor'],['financial','I work with a financial advisor'],['both','I work with both'],['none','Not currently']] }
  ];
  const $ = id => document.getElementById(id);
  const panels = {intro:$('intro-panel'),question:$('question-panel'),summary:$('summary-panel')};
  const storageKey = 'lookout-towers:investment-path:v1';
  const maxAge = 6 * 60 * 60 * 1000;
  let answers = {};
  let step = -1;
  let savedStep = -1;
  let editing = false;
  let timer;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

  function validAnswer(question, value) { return question.options.some(option => option[0] === value); }
  function restore() {
    try {
      const saved = JSON.parse(sessionStorage.getItem(storageKey) || 'null');
      if (!saved || typeof saved.savedAt !== 'number' || Date.now() - saved.savedAt > maxAge || Date.now() < saved.savedAt) return;
      questions.forEach(question => { if (validAnswer(question, saved.answers?.[question.id])) answers[question.id] = saved.answers[question.id]; });
      const firstMissing = questions.findIndex(question => !answers[question.id]);
      savedStep = firstMissing === -1 ? questions.length : firstMissing;
      if (!Object.keys(answers).length) savedStep = -1;
    } catch (_) { /* Storage is optional, including when opened from a local file. */ }
  }
  function persist() {
    try { sessionStorage.setItem(storageKey, JSON.stringify({answers, savedAt:Date.now()})); } catch (_) { /* Continue without storage. */ }
  }
  function saveStartingInterest() {
    try {
      const interest = new URLSearchParams(location.search).get('interest');
      const aliases = {income:'series-a',growth:'series-b','series-a':'series-a','series-b':'series-b',syndication:'syndication'};
      if (aliases[interest] && !answers.interest) answers.interest = aliases[interest];
    } catch (_) { /* The guide also works without URL query support. */ }
  }
  function labelFor(question) { return question.options.find(option => option[0] === answers[question.id])?.[1] || 'Not selected'; }
  function showPanel(name) { Object.entries(panels).forEach(([key,panel]) => { panel.hidden = key !== name; }); }
  function focusTitle(id) { requestAnimationFrame(() => { $(id).focus({preventScroll:true}); }); }
  function updateProgress() {
    const completed = step < 0 ? 0 : Math.min(step, questions.length);
    $('flow-progress').setAttribute('aria-valuenow', String(completed));
    $('progress-fill').style.width = `${completed / questions.length * 100}%`;
    $('progress-label').textContent = step < 0 ? '' : step >= questions.length ? 'Your conversation guide' : `${step + 1} / ${questions.length}`;
    $('home-back').hidden = step >= 0;
    $('question-back').hidden = step < 0;
  }
  function selectAnswer(index) {
    if (timer || step < 0 || step >= questions.length) return;
    const question = questions[step];
    const option = question.options[index];
    if (!option) return;
    answers[question.id] = option[0];
    persist();
    [...$('answer-list').children].forEach((button, position) => {
      const selected = position === index;
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
      button.disabled = true;
    });
    timer = window.setTimeout(() => {
      timer = undefined;
      step = editing ? questions.length : step + 1;
      editing = false;
      render();
    }, reducedMotion.matches ? 0 : 240);
  }
  function renderQuestion() {
    const question = questions[step];
    showPanel('question');
    $('question-kicker').textContent = question.kicker;
    $('question-title').textContent = question.title;
    $('question-help').textContent = question.help;
    $('answer-list').replaceChildren();
    question.options.forEach(([value,label], index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'answer-button';
      const selected = answers[question.id] === value;
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
      const key = document.createElement('span'); key.className = 'answer-key'; key.textContent = String.fromCharCode(65 + index); key.setAttribute('aria-hidden','true');
      const text = document.createElement('span'); text.className = 'answer-text'; text.textContent = label;
      const check = document.createElement('span'); check.className = 'answer-check'; check.textContent = '✓'; check.setAttribute('aria-hidden','true');
      button.append(key,text,check);
      button.addEventListener('click', () => selectAnswer(index));
      $('answer-list').append(button);
    });
    $('flow-status').textContent = `Question ${step + 1} of ${questions.length}. ${question.title}`;
    focusTitle('question-title');
  }
  function renderSummary() {
    showPanel('summary');
    $('summary-list').replaceChildren();
    questions.forEach((question,index) => {
      const row = document.createElement('div'); row.className = 'summary-row';
      const term = document.createElement('dt'); term.textContent = question.label;
      const value = document.createElement('dd'); value.textContent = labelFor(question);
      const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'edit-answer'; edit.textContent = 'Edit'; edit.setAttribute('aria-label', `Edit ${question.label.toLowerCase()}`);
      edit.addEventListener('click', () => { step = index; editing = true; render(); });
      row.append(term,value,edit); $('summary-list').append(row);
    });
    const notices = [];
    if (answers.accredited !== 'yes') notices.push('Current offerings are intended for accredited investors. The team can explain the requirements and discuss your questions; this guide does not determine eligibility.');
    if (answers.capital === 'under-50') notices.push('The published fund minimum is $50,000. Ask the team about the minimum and availability of any opportunity you are considering.');
    $('summary-notice').textContent = notices.join(' ');
    $('summary-notice').hidden = notices.length === 0;
    $('flow-status').textContent = 'Your conversation guide is ready. No selections have been sent.';
    focusTitle('summary-title');
  }
  function render() {
    updateProgress();
    if (step < 0) {
      showPanel('intro');
      $('resume-button').hidden = savedStep < 0;
      $('flow-status').textContent = '';
    } else if (step >= questions.length) renderSummary();
    else renderQuestion();
    if (step >= 0) window.scrollTo({top:0,behavior:'instant'});
  }
  function clearTimer() { if (timer) window.clearTimeout(timer); timer = undefined; }
  $('begin-button').addEventListener('click', () => { clearTimer(); step = 0; editing = false; render(); });
  $('resume-button').addEventListener('click', () => { step = savedStep; editing = false; render(); });
  $('question-back').addEventListener('click', () => {
    clearTimer();
    if (editing) { step = questions.length; editing = false; }
    else step = Math.max(-1, step - 1);
    render();
  });
  $('restart-button').addEventListener('click', () => {
    clearTimer(); answers = {}; step = -1; savedStep = -1; editing = false;
    try { sessionStorage.removeItem(storageKey); } catch (_) { /* Optional storage. */ }
    render(); $('begin-button').focus();
  });
  document.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.defaultPrevented || ['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) return;
    if (step >= 0 && step < questions.length && /^[1-4]$/.test(event.key)) {
      const index = Number(event.key) - 1;
      if (index < questions[step].options.length) { event.preventDefault(); selectAnswer(index); }
    }
  });
  $('footer-year').textContent = String(new Date().getFullYear());
  restore(); saveStartingInterest(); render();
})();
