# Reconstruction notes

The public design reference was https://investaoapark.com/. Brand and offering material came from https://lookouttowerfund.com/ and its investment, portfolio, team and contact pages. Both sites were inspected in a browser, with desktop/mobile screenshots and executed UI observations retained in the working investigation.

REA6.9.0 was used to inspect the selected shipped homepage JavaScript bundle. Parent Evidence: ev_16502322102d107a7bc064e38e70a1319289f2a77aebcaa4dfb99f188e41dfa0. Syntax parsing completed for one selected source; semantic retention and alias-selection limits made deeper semantic coverage partial. The implementation does not claim that REA recovered complete original source or the backend.

The deliverable is a new standalone HTML/CSS/JavaScript implementation. It follows the reference’s navy/ivory/amber visual system, typography, content width, section order, cards, comparison treatment, timeline, carousels, modal details, FAQs, counters and scroll behavior. It uses Lookout’s actual logo, photography, team and offering content. Different copy and media mean it is not a pixel-identical copy of the original AOAP page.

Deliberate differences: the phone header is usable rather than hidden; the comparison covers the three actual Lookout investment pathways; the conversation guide has7tailored steps instead of the reference’s12questions and hands off to the existing verified Lookout form. The original survey/booking APIs, tax claims, analytics and source-brand scripts were not copied. No new server-side submission or calendar is claimed.

Where the current Lookout homepage and investment page differ on SeriesB, the more explicit /invest wording—25%total return target over3years—was used. Inconsistent pipeline/occupancy figures were not used as hero metrics. Targets, eligibility and the meaning of preferred equity are presented with the relevant offering context.

Assets are local and original source URLs/hashes are recorded in assets/asset-manifest.json. Inter and IBM Plex Mono font-license files accompany the package. The standalone HTML embeds only the assets it uses; the ZIP additionally includes all35acquired source images.
